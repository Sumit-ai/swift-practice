//Name: Sumit Pandey
// Date: 17 June 2020
// swift practice
// just like python import is used here to call the libraries
import UIKit

// person' detail
var name = "Bob" // vaariable name
var age = 51 // age of the person
var weight = 212.51 // weight of the person
var isOrganDonator = false // Boolean

print(weight)

weight = 200.10

print(weight)
// variables are mutable
// more RAM more fater

// constants
let eyecolor = "Blue"
print(eyecolor)
